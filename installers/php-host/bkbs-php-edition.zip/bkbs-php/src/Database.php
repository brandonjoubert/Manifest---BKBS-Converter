<?php
declare(strict_types=1);

namespace Bkbs;

use PDO;

final class Database
{
    private PDO $pdo;

    public function __construct(string $dbPath)
    {
        $dir = dirname($dbPath);
        if (!is_dir($dir)) {
            mkdir($dir, 0755, true);
        }
        $this->pdo = new PDO('sqlite:' . $dbPath, null, null, [
            PDO::ATTR_ERRMODE => PDO::ERRMODE_EXCEPTION,
            PDO::ATTR_DEFAULT_FETCH_MODE => PDO::FETCH_ASSOC,
        ]);
        $this->pdo->exec('PRAGMA foreign_keys = ON');
        $this->migrate();
    }

    public function pdo(): PDO
    {
        return $this->pdo;
    }

    private function migrate(): void
    {
        $this->pdo->exec(<<<'SQL'
CREATE TABLE IF NOT EXISTS sites (
  id TEXT PRIMARY KEY,
  name TEXT NOT NULL,
  base_url TEXT NOT NULL,
  max_pages INTEGER DEFAULT 40,
  crawl_delay_ms INTEGER DEFAULT 300,
  publish_root TEXT,
  auto_publish INTEGER DEFAULT 1,
  aipref_search INTEGER DEFAULT 0,
  aipref_ai_input INTEGER DEFAULT 0,
  aipref_train_ai INTEGER DEFAULT 0,
  created_at TEXT NOT NULL
);

CREATE TABLE IF NOT EXISTS entities (
  id TEXT PRIMARY KEY,
  site_id TEXT NOT NULL,
  external_key TEXT NOT NULL,
  entity_type TEXT NOT NULL,
  name TEXT NOT NULL,
  description TEXT,
  properties TEXT DEFAULT '{}',
  relationships TEXT DEFAULT '[]',
  evidence TEXT DEFAULT '[]',
  version INTEGER DEFAULT 1,
  trust_level TEXT DEFAULT 'medium',
  source TEXT DEFAULT 'scan',
  status TEXT DEFAULT 'pending',
  notes TEXT,
  last_updated TEXT NOT NULL,
  created_at TEXT NOT NULL,
  UNIQUE(site_id, external_key),
  FOREIGN KEY(site_id) REFERENCES sites(id) ON DELETE CASCADE
);

CREATE TABLE IF NOT EXISTS scan_jobs (
  id TEXT PRIMARY KEY,
  site_id TEXT NOT NULL,
  status TEXT DEFAULT 'queued',
  pages_fetched INTEGER DEFAULT 0,
  entities_found INTEGER DEFAULT 0,
  error TEXT,
  stats_json TEXT,
  created_at TEXT NOT NULL,
  finished_at TEXT,
  FOREIGN KEY(site_id) REFERENCES sites(id) ON DELETE CASCADE
);

CREATE TABLE IF NOT EXISTS settings (
  key TEXT PRIMARY KEY,
  value TEXT NOT NULL
);

CREATE TABLE IF NOT EXISTS claims (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  entity_id TEXT NOT NULL,
  entity_type TEXT NOT NULL,
  attribute TEXT NOT NULL,
  value TEXT NOT NULL,
  source_url TEXT,
  extraction_method TEXT NOT NULL,
  confidence REAL,
  status TEXT NOT NULL,
  supersedes_id INTEGER REFERENCES claims(id),
  created_at TEXT NOT NULL,
  approved_by TEXT,
  approved_at TEXT,
  review_due_at TEXT
);
CREATE INDEX IF NOT EXISTS idx_claims_entity_attr ON claims(entity_id, attribute);
CREATE INDEX IF NOT EXISTS idx_claims_status ON claims(status);
CREATE INDEX IF NOT EXISTS idx_claims_supersedes ON claims(supersedes_id);
SQL);
        $this->ensureColumn('sites', 'aipref_search', 'aipref_search INTEGER DEFAULT 0');
        $this->ensureColumn('sites', 'aipref_ai_input', 'aipref_ai_input INTEGER DEFAULT 0');
        $this->ensureColumn('sites', 'aipref_train_ai', 'aipref_train_ai INTEGER DEFAULT 0');
        // Stage 6: clear attribute columns when claims exist for the entity.
        $this->pdo->exec(
            "UPDATE entities SET name = '', description = NULL, properties = '{}', relationships = '[]', evidence = '[]'
             WHERE id IN (SELECT DISTINCT entity_id FROM claims)"
        );
    }

    private function ensureColumn(string $table, string $column, string $ddl): void
    {
        $cols = $this->pdo->query('PRAGMA table_info(' . $table . ')')->fetchAll();
        $names = array_map(static fn($r) => (string) $r['name'], $cols);
        if (!in_array($column, $names, true)) {
            $this->pdo->exec('ALTER TABLE ' . $table . ' ADD COLUMN ' . $ddl);
        }
    }

    public function getSetting(string $key, ?string $default = null): ?string
    {
        $st = $this->pdo->prepare('SELECT value FROM settings WHERE key = ?');
        $st->execute([$key]);
        $row = $st->fetch();
        return $row ? (string) $row['value'] : $default;
    }

    public function setSetting(string $key, string $value): void
    {
        $st = $this->pdo->prepare(
            'INSERT INTO settings(key, value) VALUES(?, ?)
             ON CONFLICT(key) DO UPDATE SET value = excluded.value'
        );
        $st->execute([$key, $value]);
    }
}
